# 概要 (Summary)
<!-- なぜこの変更が必要ですか？ どのIssueを解決しますか？ -->
- 関連Issue: #

# 変更点 (Changes)
<!-- 何をしましたか？ 箇条書きで簡潔に -->
- 
- 

# レビュー観点 (Review Points)
<!-- レビュアーに特に見てほしい箇所 -->
- 

# チェックリスト (Checklist)
- [ ] 動作確認 (`npm test` passed)
- [ ] `GEMINI.md` / `docs/` の更新 (必要な場合)
- [ ] 不要なログ・コメントの削除
