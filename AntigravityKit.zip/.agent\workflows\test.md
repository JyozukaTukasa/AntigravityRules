---
description: テストコードの実行・修正を行う（Turboモード）
---

# テストフェーズ (Turbo Test)

// turbo
8. **Smart Testing (Diff-Based)**
   変更点から「影響を受けるテスト」のみを特定して実行する。
   Run: `git diff --name-only main...HEAD` (変更ファイル特定)
   
   - 変更が少なければ: Run: `npm test -- --related $(git diff --name-only main...HEAD)`
   - 変更が広範囲/特定不能なら: Run: `npm test` (Full Fallback)

2. **テスト自動作成 (Auto-Gen)**
   テストファイルが見つからない、またはカバレッジが著しく低い場合、**ユーザーの許可を得ずに** 最低限のテストケース（正常系・異常系）を新規作成する。
   （いちいち許可を取る時間を節約するため）

3. **自動修正トライアル**
   エラー内容が単純（Importミス、型定義ミスなど）な場合は、即座に修正して再実行する。
   ロジック修正が必要な場合のみ停止して報告する。

4. **⚠️ ブラウザテスト禁止**
   E2Eテスト（Playwright, Cypress等）やブラウザ操作は **AIが実行しない**。
   ブラウザでの動作確認が必要な場合は、人間に依頼すること。
