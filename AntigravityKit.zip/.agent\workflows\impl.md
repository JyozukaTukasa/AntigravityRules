---
description: 機能実装を行う（タスク分解～コーディング）
---

# 実装フェーズ (Focus Implementation)

Run: `cat .agent/rules/core.md .agent/rules/coding.md`
(Current Phase: Execution)

1. **設計の存在確認 (Safety Lock)**

1. **設計の存在確認 (Safety Lock)**
   `docs/` 配下に設計ドキュメントが存在するか確認する。
   存在しない場合は「先に `@[/design]` を実行してください」と警告して終了する。

2. **セキュリティ実装確認 (RLS Check)**
   - DB操作を含む場合、**「RLSポリシー」** が設計されているか確認する。
   - なければ即座に停止し、設計に戻るか、その場でRLSを定義する。
   - 「アプリ層でのチェックがあるからOK」は **不可** とする。

3. **アトミック・タスク分解 & 脅威分析 (Threat Modeling)**
   今回の実装を「1つのファイル」または「1つの関数」単位まで細かく分解し、**攻撃者の視点** でリスクを洗い出す。
   Run: `echo "# Implementation Task\n\n## 🛡️ Security Risk & Mitigation\n- **Attack Vector**: (e.g. SQL Injection, XSS, IDOR)\n- **Mitigation**: (e.g. Use param queries, Sanitize, RLS)\n\n## 📝 Todo\n- [ ] " > current_task.md`

4. **実装実行**
   `current_task.md` の「防御策(Mitigation)」を確実に実装すること。

   `current_task.md` の「防御策(Mitigation)」を確実に実装すること。

4. **完了報告 & テスト (Auto-Test)**
   Run: `rm current_task.md`
   // turbo
   Run: `npm test`
   「実装完了。テストも通過しました。次は `@[/ship]` へ。」
