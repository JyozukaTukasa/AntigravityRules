# Antigravity Global Rules [DEPRECATED]

This file has been sharded into `.agent/rules/*.md`.
Do not read this file.

- Core: `.agent/rules/core.md`
- Planning: `.agent/rules/planning.md`
- Coding: `.agent/rules/coding.md`
- Audit: `.agent/rules/audit.md`
