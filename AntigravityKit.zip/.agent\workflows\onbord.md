---
description: プロジェクト再開時に状況を瞬時に把握する（オンボーディング）
---

# オンボーディング・ステータス確認

1. **初期化チェック (Bootstrap)**
   // turbo
   `GEMINI.md` が存在しない場合、プロジェクト未初期化と判断する。
   Run: `ls GEMINI.md` -> If error/missing, Run: `view_file .agent/workflows/init-project.md` and follow instructions immediately.

2. プロジェクト情報の読み込み
   `GEMINI.md`, `.agent/rules/core.md`, `task.md` (あれば) を読み込む。
   Run: `cat GEMINI.md .agent/rules/core.md`
   (Check `task.md` via tools)

3. 直近の作業状況の要約
   読み込んだ情報を元に、以下の3点を簡潔に（各1-2行）報告する。
   1. **このプロジェクトは何をするものか？**
   2. **現在どこまで進んでいるか？**
   3. **次にやるべきタスクは何か？**

   出力例：
   「おかえりなさい。現在のセキュリティレベルは **L2: Standard** です。
   これは『見積もり管理システム』のリプレイス案件です。
   現在は『ユーザー管理機能』の実装が完了し、テストフェーズに入っています。
   次は『統合テストコードの作成 (integration_test.ts)』を行う必要があります。」
